package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_NUMBER = "com.example.application.example.EXTRA_NUMBER";
    public static final String EXTRA_TEXT = "com.example.application.EXTRA_TEXT";
    public String easterMonth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMain2Activity();
            }
        });
    }
    public void openMain2Activity(){
        EditText editText = (EditText) findViewById(R.id.edittext);
        int number = Integer.parseInt(editText.getText().toString());
        int a = number%19;
        int b = number/100;
        int c = number%100;
        int d = b/4;
        int e = b%4;
        int g = ((8*b)+13)/25;
        int h = (19*a+b-d-g+15)%30;
        int j = c/4;
        int k = c%4;
        int m = (a+11*h)/319;
        int r = (2*e+2*j-k-h+m+32)%7;
        int n = (h-m+r+90)/25; //Month
        int p = (h-m+r+n+19)%32; //Day
        Intent intent = new Intent(this, Main2Activity.class);

        if (n==1) {
            easterMonth="January";}
        else if (n==2) {
            easterMonth="February";}
        else if (n==3) {
            easterMonth="March";}
        else if (n==4) {
            easterMonth="April";}
        else if (n==5) {
            easterMonth="May";}
        else if (n==6) {
            easterMonth="June";}
        else if (n==7) {
            easterMonth="July";}
        else if (n==8) {
            easterMonth="August";}
        else if (n==9) {
            easterMonth="September";}
        else if (n==10) {
            easterMonth="October";}
        else if (n==11) {
            easterMonth="November";}
        else if (n==12) {
            easterMonth="December";}

        intent.putExtra(EXTRA_NUMBER, p);
        intent.putExtra(EXTRA_TEXT,easterMonth);
        startActivity(intent);
    }
}