package lab3_1;
public class InsectPopulation {
    private double pop;
    public InsectPopulation(double insect){pop=insect;}
    public void breed(){pop+=pop;}
    public void spray(){pop=pop*0.9;}
    public double getNumInsect(){return pop;}
}
