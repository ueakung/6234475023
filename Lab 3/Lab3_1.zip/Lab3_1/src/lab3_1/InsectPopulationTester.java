package lab3_1;
public class InsectPopulationTester {
    public static void main(String[] args) {
        InsectPopulation pop = new InsectPopulation(10);
        pop.breed();
        pop.spray();
        System.out.println(pop.getNumInsect());
        pop.breed();
        pop.spray();
        System.out.println(pop.getNumInsect());
        pop.breed();
        pop.spray();
        System.out.println(pop.getNumInsect());
    }    
}
