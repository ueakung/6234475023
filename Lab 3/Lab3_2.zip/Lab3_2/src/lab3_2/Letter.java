package lab3_2;
public class Letter {
    private String from,to,line,text="",allText;
    public Letter(String from,String to){this.from=from;this.to=to;}
    public void addLine(String line){text=text+line+"\n";}
    public String getText(){allText="Dear "+from+":\n\n"+text+"\nSincerely,\n\n"+to;return allText;}
}
