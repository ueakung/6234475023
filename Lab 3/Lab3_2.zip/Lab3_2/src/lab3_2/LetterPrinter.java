package lab3_2;
public class LetterPrinter {
    public static void main(String[] args) {
       Letter printer=new Letter("Jade","Clarissa");
       printer.addLine("We must find Simon quickly.");
       printer.addLine("He might be in danger.");
       System.out.println(printer.getText());
    }
    
}
