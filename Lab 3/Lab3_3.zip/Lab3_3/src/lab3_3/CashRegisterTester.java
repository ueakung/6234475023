package lab3_3;
public class CashRegisterTester {
    public static void main(String[] args) {
        CashRegister register = new CashRegister(7);
        register.recordPurchase(50);
        register.recordPurchase(10);
        register.recordTaxablePurchase(20);
        register.enterPayment(100);
        System.out.printf("Your change is "+"%.1f\n",register.giveChange());
    }
    
}
