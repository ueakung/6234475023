package lab4_1;
public class SodaCan {
    private double hight,diameter,volume,area;
    public SodaCan(double hight,double diameter){
        this.hight = hight;
        this.diameter = diameter;        
    }
    public double getVolume(){
        volume = Math.PI*(diameter/2)*(diameter/2)*hight;
        return volume;
    }
    public double getSurfaceArea(){
        area = 2*(Math.PI*(diameter/2)*(diameter/2))+(2*Math.PI*(diameter/2)*hight);
        return area;
    }
}
