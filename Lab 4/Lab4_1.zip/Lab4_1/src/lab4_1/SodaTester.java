package lab4_1;
import java.util.Scanner;
public class SodaTester {
    public static void main(String[] args) {
        double sodacan;
        Scanner h = new Scanner(System.in);
        System.out.print("Enter height: ");
        int hight = h.nextInt();
        Scanner d = new Scanner(System.in);
        System.out.print("Enter diameter: ");
        int diameter = d.nextInt();
        SodaCan can = new SodaCan(hight,diameter);
        System.out.printf("Volume: %.2f\n",can.getVolume());
        System.out.printf("Surface area: %.2f\n",can.getSurfaceArea());
    }
    
}
