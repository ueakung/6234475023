package lab4_2;
public class DigitExtractor {
    int num,divide;
    public DigitExtractor(int anInteger) {
        divide=anInteger;
    }
    public int nextDigit(){
        num=divide%10;
        divide=divide/10;
        return num;
    }
}