package lab4_3;
public class TimeInterval {
    private int hourS,hourE,minS,minE,diff;
    public TimeInterval(int start,int end){
        hourS = start/100*60;
        minS = start%100+hourS;
        hourE = end/100*60;
        minE = end%100+hourE;
        diff = Math.abs(minE - minS+1440)%1440 ;
    }
    public int getHours(){
        return diff/60;
    }
    public int getMinutes(){
        return diff%60;
    }
}
