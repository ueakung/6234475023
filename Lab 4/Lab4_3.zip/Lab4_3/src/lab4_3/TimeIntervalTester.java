package lab4_3;
import java.util.*;
public class TimeIntervalTester {
    public static void main(String[] args) {        
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = scanner.nextInt();
        System.out.print("Enter stop time: ");
        int end = scanner.nextInt();
        TimeInterval time = new TimeInterval(start,end);
        System.out.println(time.getHours()+" hours "+time.getMinutes()+" minutes");
    }
    
}
