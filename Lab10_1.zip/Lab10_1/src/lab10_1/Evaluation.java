package lab10_1;
public interface Evaluation {
    double evaluate();
    char grade(double evaluate);
}
