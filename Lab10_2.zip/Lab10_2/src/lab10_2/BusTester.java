package lab10_2;
import java.util.ArrayList;
import static lab10_2.Electric.HIGH_VOLTAGE;
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        Hybrid hybirdBus = new Hybrid(45,1.2,HIGH_VOLTAGE,150,1);
        arr.add(hybirdBus);
        CNGBus cngBus = new CNGBus(50,1,200,2);
        arr.add(cngBus);
        for(int i=0;i<arr.size();i++){
            System.out.println("ID: "+arr.get(i).getID());
            System.out.println("Emission Tier: "+arr.get(i).getEmissionTier());
            System.out.println("Accel: "+arr.get(i).getAccel());
        }
    }
    
}
