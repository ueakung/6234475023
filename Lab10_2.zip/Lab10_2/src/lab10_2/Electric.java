package lab10_2;
public interface Electric {
    public static final int HIGH_VOLTAGE = 600;
    public static final int LOW_VOLTAGE = 480;
    public double getVoltage();
}
