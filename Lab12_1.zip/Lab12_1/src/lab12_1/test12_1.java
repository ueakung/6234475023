package lab12_1;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
public class test12_1 {
    public static void main(String[] args) throws Exception{
        String str = null;
        int word = 0;
        int sent = 0;
        int err = 0;
        File file = new File("C:\\Users\\ueakung\\Desktop\\Lab Java\\Lab12_1.txt");
        Scanner in = new Scanner(System.in);
        PrintWriter output = new PrintWriter(file);
        str = in.nextLine();
        while (!str.equals("quit")){
            output.println(str);
            str = in.nextLine();
    }
        output.close();
        Scanner out = new Scanner(file);
        while (out.hasNextLine()){
            String[] line = out.nextLine().split(" ");
            word+=line.length;
            sent++;
            err+=2;
        }
        System.out.println("Total characters : "+(file.length()-err));
        System.out.println("Total words : "+word);
        System.out.println("Total lines : "+sent);
    }
}