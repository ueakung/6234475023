package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Lab2_3 {
    public static void main(String[] args) {
               GregorianCalendar cal = new GregorianCalendar(2020,Calendar.JANUARY,24);
        GregorianCalendar myBirthday = new GregorianCalendar(2000,Calendar.JUNE,1);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int calWeek = cal.get(Calendar.DAY_OF_WEEK);
        int calDay = cal.get(Calendar.DAY_OF_MONTH);
        int calMonth = cal.get(Calendar.MONTH)+1;
        int calYear = cal.get(Calendar.YEAR);
        int birthWeek = myBirthday.get(Calendar.DAY_OF_WEEK);
        int birthDay = myBirthday.get(Calendar.DAY_OF_MONTH);
        int birthMonth = myBirthday.get(Calendar.MONTH)+1;
        int birthYear = myBirthday.get(Calendar.YEAR);
        System.out.print(calWeek+" "+calDay+" "+calMonth+" "+calYear+"\n"+birthWeek+" "+birthDay+" "+birthMonth+" "+birthYear+"\n");
 
    }    
}
