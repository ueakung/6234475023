package lab5_2;
import java.awt.geom.Point2D;
import static java.lang.Double.NaN;
public class Line 
{
    private double m = NaN,b = NaN,x = NaN;
    public Line(double x, double y, double m)
    {
        this.m = m;
        this.b = y-m*x;
    }
    public Line(double x1, double y1, double x2, double y2)
    {
        this.m = (y2-y1)/(x2-x1);
        this.b = y1-m*x1;
    }
    public Line(double m, double b)
    {
        this.m = m;
        this.b = b;
    }
    public Line(double a)
    {
        this.x = a;
    }
    public boolean isParallel(Line line)
    {
        return m == line.m;
    }
    public boolean equals(Line line)
    {
        return (m == line.m) && (b == line.b);
    }
    public boolean isIntersect(Line line)
    {
        return m != line.m;
    }
    public Point2D.Double getIntersectionPoint(Line line)
    {
        Double lineM = line.m;
        Double objM = m;
        Double x,y;
        if (objM.isNaN())
        {
            x = this.x;
        }
        else if (lineM.isNaN())
        {
            x = line.x;
        }
        else
        {
            x = (b-line.b)/(line.m-m);
        }
        y = m*x+b;
        Point2D.Double point = new Point2D.Double(x,y);
        {
            return point;
        }
    }
}