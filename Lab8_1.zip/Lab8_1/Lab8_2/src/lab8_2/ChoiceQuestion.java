package lab8_2;
import java.util.ArrayList;
public class ChoiceQuestion extends Question{
    private ArrayList<String> choices;
    public ChoiceQuestion(){
        super();
    }
    public ChoiceQuestion(String text){
        super(text);
    }
    public void addChoice(String choice,boolean correct){
        choices.add(choice);
        if(correct){
            super.setAnswer(choice);
        }
    }
    public void display(){
        super.display();
        for(int i=0;i<choices.size();i++){
            System.out.println(i+1+": "+choices.get(i));
        }
    }
    public boolean checkAnswer(String response){
        if(choices.get(Integer.valueOf(response)-1)==super.getAnswer()){
            return true;
        }
    return false;
    }
}
