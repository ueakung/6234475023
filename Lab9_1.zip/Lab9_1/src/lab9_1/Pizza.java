package lab9_1;
public class Pizza {
    private String name;
    private double price;
    public Pizza(String name,double price){
        this.name=name;
        this.price=price;
    }
    public double getPrice(){
        return price;
    }
    public String getMenu(){
        return name;
    }
    public String getSpecial(){
        return "";
    }
}
