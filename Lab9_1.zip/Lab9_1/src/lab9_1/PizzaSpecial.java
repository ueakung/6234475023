package lab9_1;
public class PizzaSpecial extends Pizza{
    private String special;
    public PizzaSpecial(String name,double price,String special){
        super(name,price);
        this.special=special;
    }
    public String getSpecial(){
        return " special : "+special;
    }
}
